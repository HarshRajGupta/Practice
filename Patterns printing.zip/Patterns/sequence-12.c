/*  No of rows - input from user

example - 4
                                *
                               ***
                              *****
                             *******
*/
#include<stdio.h>
int main(void)
{
    int a,b,c,d,i;
    a=1;
    printf("How many rows do you want?\n");
    scanf("%d",&i);
    while (a<=i)
    {
        for(b=1;b<41-a;b++)
        {
            printf(" ");
        }

        for(c=1;c<=2*a-1;c++)
        {
            printf("*");
        }
        printf("\n");

        a=a+1;
    }
    return 0;
}
